<template>
  <div id="app" class="main-container">
   <my-header></my-header>
   <navigation :active="activeModule"></navigation> 
   <div class="main-content"> 
    <transition name="fade" mode="out-in">
      <router-view></router-view>
    </transition>
    </div>
  </div>
</template>

<script>
import myHeader from './components/common/Header'
import navigation from './components/common/Navigation'

export default {
  components:{
    navigation,myHeader
  },
  data () {
    return {
      activeModule:this.activeModule,
    }
  },
  created () {
    this.navChange()
  },
 watch: {
    '$route': 'navChange',
  },
  methods:{
    navChange:function(){
       if(this.$route.name !=null){
          if (this.$route.name=='index') {
            this.activeModule ='home';
         }else{
            this.activeModule =this.$route.name;
            this.transitionName = 'slide-right';
         }       
       }

    },
    startHacking () {
      this.$notify({
        title: 'It Works',
        message: 'We have laid the groundwork for you. Now it\'s your time to build something epic!',
        duration: 6000
      })
    }

  }
}
</script>

<style>
body {
  font-family: Microsoft YaHei, sans-serif;

}
input, textarea, keygen, select, button {
    font: 13.3333px;
   font-family: Microsoft YaHei, sans-serif;
}
.fade-enter-active, .fade-leave-active {
  transition: opacity .5s ease;
}
.fade-enter, .fade-leave-active {
  opacity: 0
}
body{
    margin:0px;
}

.main-content {
    height: 100%;
    overflow: hidden;
    padding: 0;
    margin: 0;
}
.main-container:before {
    display: block;
    content: "";
    position: absolute;
    z-index: -2;
    width: 100%;
    max-width: inherit;
    bottom: 0;
    top: 0;
    background-color: #FFF;
}
*, :after, :before {
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
}
*/
.main-container {
    width: 100%;
    overflow: hidden;
    height: 100%;
    margin: 0;
    padding: 0;
 }
 * {
    box-sizing: border-box;
}

[class*=" fa-"], [class^=fa-] {
    vertical-align: baseline;
    margin-right: 10px;
}

[class*=" fa-"], [class^=fa-] {
 
    speak: none;
    font-style: normal;
    font-weight: 400;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    vertical-align: baseline;
    display: inline-block;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

</style>
