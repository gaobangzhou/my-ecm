<template>
<div>

</div>
</template>

<script>


  export default {

    data(){
      return{
        logoWihte:logo
      }
    },
    methods: {
      handleSelect(key, keyPath) {
        console.log(key, keyPath);
      }
    }
  }
</script>

<style>


</style>