<template>
<div>
  <input></input>
</div>
</template>

<script>


  export default {

    data(){
      return{
        logoWihte:logo
      }
    },
    methods: {
      
    }
  }
</script>

<style>


</style>