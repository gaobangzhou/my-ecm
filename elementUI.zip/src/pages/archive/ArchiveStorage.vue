<template>
<div>
 <h1>
 {{msg}}
 </h1>
</div>
</template>

<script>
export default {

  data () {
    return {
      msg: 'this is Storage Page'
    }
  }
}
</script>