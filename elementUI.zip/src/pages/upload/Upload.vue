<template>
<div>
<el-input
  placeholder="请输入内容"
  v-model="input1"
  :disabled="true">
</el-input>
</div>
</template>

<script>
export default {

  data () {
    return {
      msg: 'this is upload Page',
      input1:''
    }
  }
}
</script>

<style>

</style>